
function ShowstatusBar(varint,varstr)
{
	var text;
	switch(varint)
	{
		case 0:
			text = "<font size='2' color='#00ff00'>";
			break;
		case 1:  //������Ϣ
			text = "<font size='2' color='#ff0000' style='font-weight:bold'>";
			break;
		default:
			text = "<font size='2' color='#00ff00'>";
			break;
	}
	text += "&nbsp;"+"&nbsp;"+"&nbsp;"+"&nbsp;"+"&nbsp;"+"&nbsp;"+"&nbsp;"+varstr;
	text += "</font>";
	
	sbTxt.innerHTML = text;
}